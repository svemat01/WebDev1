## PWA på github 

Om ditt användarnamn är **bygren**  
Skapa då ett repository som heter: **bygren**.github.io  
Ladda upp hela ditt projekt.  

## Skapa olika ikoner
Oftas räcker det med en favicon.ico på 32x32 px och en ikon med storleken 512x512 px.  
Blir dock bättre med flera png-ikoner.  
### Verktyg som gör om en ikon till olika storlekar
https://tools.crawlink.com/tools/pwa-icon-generator/